define(function (require, exports, module) {
  'use strict';

  module.exports = {
    root: true,
    de: true,
    es: true,
    fr: true,
    gl: true,
    it: true,
    ru: true,
    sv: true,
    uk: true,
    pl: true
  };
});
