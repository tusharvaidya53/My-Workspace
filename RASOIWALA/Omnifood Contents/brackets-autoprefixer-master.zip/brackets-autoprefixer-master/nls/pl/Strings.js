define({
  // Generic.
  OK: 'OK',
  CANCEL: 'Anuluj',
  RESET: 'Resetuj',

  // Menu.
  MENU_ON_SAVE: 'Auto prefixuj podczas zapisu',
  MENU_ON_CHANGE: 'Auto prefixuj kiedy plik jest zmodyfikowany',
  MENU_SELECTION: 'Auto prefixuj zaznaczone',
  MENU_SETTINGS: 'Ustawienia Autoprefixera...',

  // Settings dialog.
  SETTINGS_TITLE: 'Ustawienia Autoprefixera',
  SETTINGS_VISUAL_CASCADE: 'Kaskada wizualna',
  SETTINGS_BROWSERS: 'Przeglądarki'
});
